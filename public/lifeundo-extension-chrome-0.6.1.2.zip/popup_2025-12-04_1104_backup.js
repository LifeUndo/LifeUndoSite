// Backup of popup.js on 2025-12-04 11:04

